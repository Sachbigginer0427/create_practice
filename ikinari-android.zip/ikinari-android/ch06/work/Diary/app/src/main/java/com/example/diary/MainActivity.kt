package com.example.diary

import android.content.Intent
import android.os.Bundle
import android.widget.SimpleAdapter
import androidx.appcompat.app.AppCompatActivity
import com.example.diary.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sampleData = mutableListOf(
            mapOf ("date" to "2024/01/01", "text" to "ここに日記のテキストが入ります。"),
            mapOf ("date" to "2024/02/01", "text" to "ここに日記のテキストが入ります。"),
            mapOf ("date" to "2024/03/01", "text" to "ここに日記のテキストが入ります。"),
            mapOf ("date" to "2024/04/01", "text" to "ここに日記のテキストが入ります。"),
            mapOf ("date" to "2024/05/01", "text" to "ここに日記のテキストが入ります。"),
            mapOf ("date" to "2024/06/01", "text" to "ここに日記のテキストが入ります。"),
            mapOf ("date" to "2024/07/01", "text" to "ここに日記のテキストが入ります。"),
            mapOf ("date" to "2024/08/01", "text" to "ここに日記のテキストが入ります。"),
            mapOf ("date" to "2024/09/01", "text" to "ここに日記のテキストが入ります。"),
            mapOf ("date" to "2024/10/01", "text" to "ここに日記のテキストが入ります。"),
            mapOf ("date" to "2024/11/01", "text" to "ここに日記のテキストが入ります。"),
            mapOf ("date" to "2024/12/01", "text" to "ここに日記のテキストが入ります。"),
        )
        binding.listView.adapter = SimpleAdapter(
            this,
            sampleData,
            R.layout.list_item,
            arrayOf("date", "text"),
            intArrayOf(R.id.itemDate, R.id.itemText)
        )

        binding.fab.setOnClickListener {
            startActivity(Intent(this@MainActivity, EditActivity::class.java))
        }
    }
}